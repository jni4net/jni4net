package democalc;

import java.util.Random;

public class DemoCalc implements ICalc {
    Random r = new Random();

    public int MySuperSmartFunctionIDontHaveInJava(String question) {
        if (question.equals("Answer to the Ultimate Question of Life, the Universe, and Everything")) {
            return 42;
        }

        return r.nextInt();
    }
}

