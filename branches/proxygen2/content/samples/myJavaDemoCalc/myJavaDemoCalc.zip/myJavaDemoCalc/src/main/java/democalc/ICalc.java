package democalc;

public interface ICalc
{
    int MySuperSmartFunctionIDontHaveInJava(String question);
}
