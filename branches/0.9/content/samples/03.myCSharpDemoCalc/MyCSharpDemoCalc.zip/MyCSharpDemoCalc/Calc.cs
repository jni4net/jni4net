﻿using System;

namespace MyCSharpDemoCalc
{
    public interface ICalc
    {
        int MySuperSmartFunctionIDontHaveInJava(string question);
    }

    public class DemoCalc : ICalc
    {
        private readonly Random r = new Random();

        public int MySuperSmartFunctionIDontHaveInJava(string question)
        {
            if (question == "Answer to the Ultimate Question of Life, the Universe, and Everything")
            {
                return 42;
            }
            return r.Next();
        }
    }
}
